import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';

class MyForm extends React.Component {
  render() {
    const mystyle = {
      color: "white",
      backgroundColor: "DodgerBlue",
      padding: "10px",
      fontFamily: "times new roman"
    };
    return (
      <form>
        <center><h1 style={mystyle}>STUDENT REGISTRATION FORM </h1></center>
         <p>STUDENT ID:</p>
      <input
        type='text'
        name='userid'
        />
      <p>STUDENT NAME:</p>
      <input
        type='text'
        name='username'
       
      />
       <p>DEPT.NAME:</p>
      <input
        type='text'
        name='userdpte'
        
      />
       <p>TOTAL MARKS:</p>
      <input
        type='text'
        name='usermark'
        
      />
      <p>LOCATION:</p>
      <input
        type='text'
        name='userlocation'
        
      />
       <br/>
      <br/>
      <input type='submit' />
      
      </form>
    );
  }
}
ReactDOM.render(<MyForm />, document.getElementById('root'));
